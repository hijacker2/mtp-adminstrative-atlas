import { Moon, Sun } from 'lucide-react'
import { Link, NavLink, useLocation } from 'react-router-dom'
import { useTheme } from './ThemeProvider'

const nextTheme = {
  light: 'Dark',
  dark: 'System',
  system: 'Light',
} as const

export default function SiteHeader() {
  const { mode, resolvedTheme, cycleTheme } = useTheme()
  const location = useLocation()
  const isObservatory = location.pathname === '/observatory'

  return (
    <header className="site-header">
      <Link className="wordmark" to="/" aria-label="MTP Administrative Atlas home">
        <span className="wordmark-seal" aria-hidden="true">M</span>
        <span className="wordmark-copy">
          <strong>MTP</strong>
          <span>Administrative Atlas</span>
        </span>
      </Link>
      <nav className="primary-nav" aria-label="Main navigation">
        <NavLink className={({ isActive }) => isActive && !isObservatory ? 'nav-current' : ''} to="/" end>Atlas</NavLink>
        <a href="/#states">States</a>
        <a href="/#sources">Sources</a>
        <a href="/#method">Method</a>
        <NavLink className={({ isActive }) => isActive ? 'nav-current' : ''} to="/observatory">Burden Observatory</NavLink>
      </nav>
      <button
        className="theme-toggle"
        type="button"
        onClick={cycleTheme}
        aria-label={`Theme is ${mode}. Activate to switch to ${nextTheme[mode]} mode.`}
        title={`Theme: ${mode}. Click to switch to ${nextTheme[mode]}.`}
      >
        {resolvedTheme === 'dark' ? <Moon size={16} aria-hidden="true" /> : <Sun size={16} aria-hidden="true" />}
        <span>{mode === 'system' ? 'System' : mode === 'dark' ? 'Dark' : 'Light'}</span>
      </button>
      <details className="future-menu">
        <summary>More <span className="forthcoming-label">Forthcoming</span></summary>
        <div className="future-menu-panel">
          <p>Future sections</p>
          <span>Visualisations</span>
          <span>Field notes</span>
          <span>Comparative essays</span>
          <small>Not part of this release</small>
        </div>
      </details>
    </header>
  )
}
